class MouseButton(object):

    LEFT = 0
    MIDDLE = 1
    RIGHT = 2
